<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "admissionsystem";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$facultyName = $_POST['facultyName'] ?? '';
$facultyId = $_POST['facultyId'] ?? '';
$department = $_POST['department'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$joiningDate = $_POST['joiningDate'] ?? '';

// Insert into DB
$sql = "INSERT INTO faculty (faculty_name, faculty_id, department, email, phone, joining_date)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("ssssss", $facultyName, $facultyId, $department, $email, $phone, $joiningDate);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
