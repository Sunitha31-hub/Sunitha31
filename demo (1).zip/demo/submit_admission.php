<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "admissionsystem";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$studentName = $_POST['studentName'] ?? '';
$studentId = $_POST['studentId'] ?? '';
$dob = $_POST['dob'] ?? '';
$department = $_POST['department'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';

$sql = "INSERT INTO students (student_name, student_id, dob, department, email, phone)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("ssssss", $studentName, $studentId, $dob, $department, $email, $phone);

if ($stmt->execute()) {
    echo "Student admission submitted successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
